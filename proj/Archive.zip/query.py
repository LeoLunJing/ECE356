import main
import user
import post
import dbConnection

cnx = dbConnection.connectDB()
cursor = cnx.cursor()

def insert_post(post):

    postID = newPostID()
    add_post = ("INSERT INTO Post "
              "(post_id, content, postBy) "
              "VALUES (%(post_id)s, %(content)s, %(postBy)s)")

    data_post = (postID, post.content, post.postBy)

    

    # Insert new Post
    cursor.execute(add_post, data_post)  

    for topic in post.topics:
        add_postTopic = ("INSERT INTO PostTopics "
                        "(post_id, topicName) "
                        "VALUES (%(post_id)s, %(topicName)s)")
        data_postTopics = (postID, topic)

        # Insert new PostTopics
        cursor.execute(add_postTopic, data_postTopics)  

    cnx.commit()

def newPostID():
    return 1 