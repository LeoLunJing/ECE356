import query
import post

class user:
    def __init__(self, 
                 user_id,
                 name):
        self.user_id = user_id
        self.name = name

    def post(self, content, topics):
        content = "Hello World."
        topics = ["greetings", "test"]

        newpost = post.post(self.user_id, content, topics)
        newpost.save()

