from query import insert_post
import query

class post:
    def __init__(self, user_id, content, topics):
        self.postBy = user_id
        self.content = content
        self.topics = topics

    def save(self):
        insert_post(self)

