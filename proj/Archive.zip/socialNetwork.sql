CREATE DATABASE IF NOT EXISTS `SocialNetwork`


drop table if exists User;
drop table if exists Posts;
drop table if exists Prereq;
drop table if exists Course;
drop table if exists Classroom;
drop table if exists Department;

create table User (user_id char(8), name char(10), primary key (user_id));
insert into User values ('bob001', 'Bob'),
                        ('alex001', 'Alex'),

create table Post (post_id char(8), postBy char(8), content text(), primary key (post_id));
insert into Post values ('1', 'bob001', 'blablabla...'),
                        ('2', 'bob001', 'blablabla...'),
                        ('3', 'alex001', 'blablabla...'),

create table PostTopics (post_id char(8), topicName char(10), primary key (post_id, topicName));
insert into Post values ('2', 'bullshit'),

-- create table Department (deptID char(8), deptName varchar(50), faculty varchar(50), primary key(deptID));
-- insert into Department values ('ECE' , 'Electrical and Computer Engineering' , 'Engineering' ),
--        	    	       	      ('CS'  , 'Computer Science' , 'Math' ),
-- 			      ('MATH'  , 'Math' , 'Math' ),
-- 			      ('C&O'  , 'Combinatorics and Optimization' , 'Math' );

-- create table Instructor(instID int, instName char(10), deptID char(4), sessional bool, primary key (instID), foreign key (deptID) references Department(deptID));
-- insert into Instructor values (1 , 'Nelson' , 'ECE' , false ),
--        	    	       	      (3 , 'Jimbo'  , 'ECE' , false   ),
-- 			      (4 , 'Moe'    , 'CS'  , true ),
-- 			      (5 , 'Lenny'  , 'CS'  , false   ),
-- 			      (7 , 'Whoever'  , 'MATH'  , false   );

-- create table Course (courseID char(8), courseName varchar(50), deptID char(4),
--        	     	    primary key(courseID),
--        	     	    foreign key (deptID) references Department(deptID));
-- insert into Course values ('ECE222'  , 'Digital Computers' , 'ECE' ),                -- These three exist so that the foreign key doesn't fail
--        	    	   	  ('ECE250'  , 'Algorithms and Data Structures' , 'ECE' ),
--        	    	   	  ('ECE290'  , 'Engineering Profession, Ethics, and Law' , 'ECE' ),
--        	    	   	  ('ECE356'  , 'Database Systems' , 'ECE' ),
--        	    	   	  ('ECE358'  , 'Computer Networks' , 'ECE' ),
-- 			  ('ECE390'  , 'Engineering Design' , 'ECE' ),
-- 			  ('MATH117' , 'Calculus 1'  , 'MATH' );

-- create table Prereq (courseID char(8), prereqID char(8),
--        	     	    primary key(courseID, prereqID),
--        	     	    foreign key (courseID) references Course(courseID),
-- 		    foreign key (prereqID) references Course(courseID));
-- insert into Prereq values ('ECE356'  , 'ECE250'),
--        	    	   	  ('ECE358'  , 'ECE222'),
-- 			  ('ECE390'  , 'ECE290' );

-- create table Offering (courseID char(8), section int, termCode decimal(4), roomID char(8), instID int, enrollment int,
--        	     	      primary key(courseID,section,termCode),
--        	     	      foreign key (instID) references Instructor(instID),
--        	     	      foreign key (roomID) references Classroom(roomID),
-- 		      foreign key (courseID) references Course (courseID));
-- insert into Offering values ('ECE356'  , 1 , 1191 , 'E74417' , 1 , 64 ),
--        	    	     	    ('ECE356'  , 2 , 1191 , 'E74417' , 3 , 123 ),
-- 			    ('ECE290'  , 1 , 1191 , 'E74053' , 3 , 102 ),
-- 			    ('ECE390'  , 1 , 1191 , 'E74053' , 3 , 102 ),
-- 			    ('MATH117' , 1 , 1189 , 'RCH111' , 5 , 89 );

