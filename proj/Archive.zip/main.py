import dbConnection

def main():
    cnx = dbConnection.connectDB()
    cursor = cnx.cursor()



if __name__ == '__main__':
    main()
